<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051746018e8             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Woocommerce; use Pmpr\Cover\Herfe\Container; abstract class Common extends Container { }
