<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46ad485fc             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Woocommerce; use Pmpr\Cover\Herfe\Container; abstract class Common extends Container { }
