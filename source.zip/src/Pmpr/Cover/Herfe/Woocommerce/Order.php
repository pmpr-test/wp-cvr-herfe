<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c72dcc8726             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Woocommerce; class Order extends Template { public function ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea = [], $ugugagoguiycqeys = []) : array { switch ($ymqmyyeuycgmigyo) { case self::ooucaegqiuieiwwu: $ugugagoguiycqeys = ['h2' => ['class' => 'h4'], '.woocommerce-order-details' => ['class' => 'table-responsive'], '.woocommerce-table' => ['class' => 'table table-borderless mb-5'], '.download-product a, .product-name a' => ['class' => 'text-secondary-primary font-weight-bold'], '.woocommerce-table--order-details .product-total, .woocommerce-table--order-details tfoot td' => ['class' => 'text-right']]; break; case self::ykigkwqykmqcwueq: $ugugagoguiycqeys = ['.woocommerce-order-downloads' => ['class' => 'table-responsive'], '.woocommerce-table thead' => ['class' => 'd-none d-md-revert'], 'tr' => ['class' => 'mobile-responsive'], '.woocommerce-MyAccount-downloads-file' => ['class' => 'btn btn-sm bg-primary-secondary text-white']]; break; case self::oamssweieucmuaau: $ugugagoguiycqeys = ['h2' => ['class' => 'h4']]; break; } return parent::ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea, $ugugagoguiycqeys); } }
