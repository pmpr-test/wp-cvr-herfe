<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670520e2dd031             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Component; use Pmpr\Cover\Herfe\Component\Module\Module; use Pmpr\Cover\Herfe\Container; class Component extends Container { public function mameiwsayuyquoeq() { Module::symcgieuakksimmu(); } }
