<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6723561c9802b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Component; use Pmpr\Cover\Herfe\Component\Module\Contact; use Pmpr\Cover\Herfe\Container; class Component extends Container { public function mameiwsayuyquoeq() { Contact::symcgieuakksimmu(); } }
