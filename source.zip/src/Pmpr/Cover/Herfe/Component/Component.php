<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67052f2951511             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Component; use Pmpr\Cover\Herfe\Component\Module\Module; use Pmpr\Cover\Herfe\Container; class Component extends Container { public function mameiwsayuyquoeq() { Module::symcgieuakksimmu(); } }
