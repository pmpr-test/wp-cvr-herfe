<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7736f3f8             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Component\Module; use Pmpr\Cover\Herfe\Container; abstract class Common extends Container { }
