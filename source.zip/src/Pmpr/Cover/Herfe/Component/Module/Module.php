<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670cfff9ed68b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Component\Module; class Module extends Common { public function mameiwsayuyquoeq() { Contact::symcgieuakksimmu(); } }
