<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             676e6b402df87             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\x69\x6e\x79\x5f\x6d\143\x65\x5f\142\145\146\x6f\x72\145\x5f\151\x6e\151\x74", [$this, "\141\x63\141\x75\167\145\161\171\171\x75\147\167\x69\x73\161\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\x63\x65\137\142\x75\164\x74\x6f\156\x73", [$this, "\141\163\141\x71\145\147\x65\167\165\151\x71\145\x65\x63\165\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\x6f\156\164\x73\x69\x7a\145\163\x65\154\x65\x63\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\x6f\x6e\x74\x73\151\172\145\x5f\146\x6f\162\x6d\141\x74\x73"] = "\70\160\x78\x20\61\60\160\x78\40\x31\62\x70\x78\x20\x31\x34\160\170\x20\61\x36\160\170\40\x32\60\160\170\x20\62\64\160\x78\x20\62\x38\x70\x78\x20\x33\62\x70\170\40\63\x36\x70\x78\x20\64\x38\160\x78\x20\66\60\x70\170\x20\67\x32\x70\170\40\x39\66\x70\x78"; return $iwsskoiwswyqeuee; } }
