<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46ad485fc             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\x69\156\x79\x5f\155\x63\145\x5f\142\145\x66\x6f\162\145\x5f\151\156\x69\x74", [$this, "\141\143\141\x75\167\145\x71\171\171\165\147\x77\x69\x73\161\143"], PHP_INT_MAX)->cecaguuoecmccuse("\155\x63\145\x5f\x62\x75\164\x74\x6f\x6e\163", [$this, "\x61\163\141\x71\145\147\x65\167\x75\x69\161\145\145\143\x75\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\157\x6e\164\163\151\172\145\x73\x65\154\145\143\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\x6f\x6e\x74\x73\151\x7a\145\x5f\146\x6f\x72\155\141\164\x73"] = "\x38\160\x78\x20\61\60\160\170\x20\x31\x32\160\x78\x20\61\64\x70\x78\x20\x31\x36\x70\170\40\62\x30\160\x78\40\62\64\160\170\x20\62\x38\x70\170\40\63\62\160\170\40\x33\66\x70\170\x20\x34\x38\x70\x78\40\66\60\x70\170\40\67\62\160\x78\x20\71\66\160\x78"; return $iwsskoiwswyqeuee; } }
