<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9fdf1fbfc             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\x69\156\x79\137\x6d\143\145\x5f\142\145\x66\x6f\162\x65\x5f\151\x6e\151\x74", [$this, "\141\x63\141\x75\167\x65\161\x79\171\165\147\x77\151\x73\161\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\143\x65\137\x62\165\164\x74\157\156\163", [$this, "\x61\x73\141\161\x65\147\x65\x77\x75\x69\x71\x65\145\143\x75\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\x6f\x6e\x74\x73\151\x7a\145\x73\145\x6c\x65\143\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\157\x6e\x74\163\x69\172\145\137\x66\x6f\162\155\x61\164\163"] = "\70\x70\170\40\61\60\160\170\x20\x31\62\160\170\40\x31\64\x70\x78\40\x31\66\160\170\40\x32\60\x70\x78\40\62\64\160\x78\x20\x32\70\160\170\40\63\62\160\170\40\63\66\160\170\x20\64\70\x70\x78\x20\x36\x30\x70\x78\x20\x37\62\x70\x78\x20\x39\66\160\170"; return $iwsskoiwswyqeuee; } }
