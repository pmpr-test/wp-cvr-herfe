<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716e6c25f22f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\151\156\171\x5f\x6d\x63\x65\137\x62\145\x66\x6f\162\145\x5f\x69\x6e\151\x74", [$this, "\141\143\141\165\167\145\161\171\x79\x75\x67\167\x69\163\161\143"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\143\145\137\142\165\164\164\157\x6e\163", [$this, "\x61\163\141\x71\x65\147\x65\x77\x75\x69\161\x65\x65\143\x75\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\157\156\x74\163\151\x7a\145\x73\145\x6c\145\143\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\157\156\164\163\x69\172\145\137\x66\x6f\x72\155\x61\164\163"] = "\x38\x70\170\x20\61\x30\160\170\40\x31\x32\160\170\x20\61\64\160\x78\x20\61\x36\160\x78\x20\62\x30\x70\x78\40\62\64\x70\170\x20\x32\70\160\170\x20\x33\x32\160\170\x20\63\66\x70\x78\x20\64\x38\160\170\x20\66\60\x70\x78\40\x37\x32\x70\x78\40\x39\x36\160\170"; return $iwsskoiwswyqeuee; } }
