<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc06044c94             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\151\x6e\x79\x5f\155\x63\x65\137\142\x65\x66\x6f\x72\x65\137\x69\x6e\151\x74", [$this, "\x61\143\x61\x75\167\x65\161\x79\171\165\147\167\151\163\x71\143"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\143\x65\137\x62\165\x74\164\x6f\156\163", [$this, "\141\x73\x61\x71\x65\x67\x65\x77\165\x69\x71\x65\145\143\x75\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\157\x6e\x74\163\x69\172\145\163\145\154\x65\x63\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\157\x6e\x74\x73\151\x7a\x65\137\146\157\x72\155\x61\x74\x73"] = "\70\x70\x78\40\61\60\160\x78\x20\x31\62\160\x78\40\61\x34\x70\170\40\x31\x36\160\170\40\62\60\x70\170\40\62\64\160\170\40\62\x38\x70\170\x20\x33\62\x70\170\40\x33\66\160\170\40\64\x38\x70\x78\40\66\x30\x70\x78\40\x37\x32\160\170\40\71\x36\160\170"; return $iwsskoiwswyqeuee; } }
