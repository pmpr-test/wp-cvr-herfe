<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6786e8493ce65             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\151\156\171\x5f\155\143\x65\x5f\x62\x65\146\157\162\x65\137\151\x6e\151\164", [$this, "\141\x63\x61\x75\x77\x65\161\x79\171\x75\x67\167\151\163\161\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\143\145\137\x62\x75\164\164\x6f\156\163", [$this, "\141\x73\141\161\145\x67\x65\x77\x75\151\x71\x65\x65\x63\165\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\x6f\156\164\x73\x69\x7a\x65\x73\145\x6c\145\x63\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\157\x6e\164\163\x69\172\x65\x5f\146\x6f\x72\155\x61\164\x73"] = "\x38\x70\x78\40\61\60\160\x78\40\x31\x32\160\x78\x20\61\64\x70\170\40\61\66\x70\170\40\x32\x30\160\x78\x20\x32\x34\x70\x78\40\x32\x38\160\170\x20\63\62\160\170\x20\x33\x36\x70\x78\x20\64\x38\160\170\40\x36\x30\x70\170\40\x37\62\160\x78\x20\71\x36\160\x78"; return $iwsskoiwswyqeuee; } }
