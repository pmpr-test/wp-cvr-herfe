<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae18f33bb0             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\151\x6e\171\x5f\x6d\x63\x65\x5f\142\x65\x66\157\x72\145\137\x69\x6e\151\x74", [$this, "\x61\x63\141\x75\167\x65\x71\171\171\x75\x67\167\x69\x73\161\143"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\143\x65\x5f\142\165\164\164\x6f\156\163", [$this, "\141\163\x61\161\x65\147\x65\167\165\x69\x71\x65\x65\143\x75\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\x6f\x6e\164\163\x69\x7a\145\163\x65\x6c\x65\x63\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\x6f\156\x74\163\151\x7a\145\x5f\x66\x6f\162\x6d\x61\x74\163"] = "\70\x70\170\x20\61\x30\x70\170\40\61\62\160\x78\40\x31\64\160\x78\40\x31\66\160\x78\40\x32\x30\x70\x78\x20\62\64\x70\x78\40\x32\x38\160\170\40\x33\x32\x70\x78\x20\x33\66\x70\170\x20\x34\x38\x70\x78\x20\66\x30\x70\170\40\67\x32\160\x78\40\71\66\x70\x78"; return $iwsskoiwswyqeuee; } }
