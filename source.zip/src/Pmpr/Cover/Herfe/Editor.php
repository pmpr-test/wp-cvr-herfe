<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716e5f3e0948             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\x69\156\x79\137\155\143\x65\137\x62\x65\x66\x6f\162\145\137\x69\156\x69\164", [$this, "\x61\x63\x61\x75\x77\145\161\171\x79\x75\147\167\151\163\x71\143"], PHP_INT_MAX)->cecaguuoecmccuse("\155\143\145\x5f\142\165\x74\164\x6f\x6e\x73", [$this, "\x61\x73\x61\161\x65\x67\x65\167\x75\x69\161\145\x65\143\x75\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\x6f\x6e\x74\x73\x69\x7a\145\x73\145\x6c\x65\x63\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\157\x6e\x74\163\151\172\x65\137\x66\157\162\x6d\141\x74\x73"] = "\70\160\170\40\x31\60\160\170\x20\61\x32\160\x78\40\61\x34\160\x78\x20\61\x36\160\170\x20\x32\x30\160\x78\40\62\x34\160\x78\40\62\70\x70\170\40\x33\x32\x70\x78\40\x33\x36\160\170\x20\x34\70\x70\x78\x20\x36\60\160\170\40\67\x32\x70\x78\x20\x39\x36\x70\170"; return $iwsskoiwswyqeuee; } }
