<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebe57815d             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\x69\156\171\x5f\155\143\x65\137\142\145\x66\x6f\162\145\x5f\151\156\151\164", [$this, "\141\143\141\x75\167\x65\161\x79\171\x75\x67\167\x69\163\161\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\x63\x65\x5f\142\x75\x74\164\157\x6e\163", [$this, "\x61\x73\141\x71\145\147\x65\x77\x75\x69\x71\x65\145\x63\165\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\157\156\164\x73\x69\x7a\x65\x73\145\x6c\x65\x63\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\x6f\156\x74\163\x69\x7a\145\x5f\x66\x6f\x72\x6d\x61\164\163"] = "\x38\x70\170\x20\61\x30\160\x78\x20\x31\62\160\x78\x20\x31\64\160\x78\x20\x31\66\160\x78\x20\62\x30\x70\x78\x20\62\64\x70\170\40\62\70\160\170\x20\x33\62\160\170\40\63\66\x70\x78\x20\x34\70\x70\170\x20\66\x30\160\170\40\x37\x32\160\x78\40\71\x36\160\x78"; return $iwsskoiwswyqeuee; } }
