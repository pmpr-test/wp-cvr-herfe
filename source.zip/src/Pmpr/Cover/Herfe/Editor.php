<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67052f2951511             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\151\x6e\171\x5f\155\x63\x65\137\142\x65\146\157\x72\x65\x5f\151\x6e\151\x74", [$this, "\141\143\141\x75\167\145\x71\171\x79\165\x67\x77\151\x73\161\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\x63\145\x5f\142\x75\x74\164\157\x6e\163", [$this, "\x61\x73\x61\x71\x65\147\x65\167\165\x69\161\145\x65\x63\x75\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\x6f\x6e\164\163\x69\x7a\x65\x73\145\154\145\143\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\157\156\164\163\x69\172\145\x5f\146\157\x72\x6d\141\164\x73"] = "\x38\160\170\x20\61\x30\x70\x78\40\61\x32\x70\x78\x20\61\x34\160\x78\x20\61\x36\x70\x78\x20\62\x30\160\x78\x20\62\64\x70\x78\40\62\70\x70\x78\x20\x33\62\160\170\40\x33\x36\x70\x78\40\x34\x38\160\170\40\x36\x30\160\x78\x20\67\x32\x70\170\40\71\66\x70\x78"; return $iwsskoiwswyqeuee; } }
