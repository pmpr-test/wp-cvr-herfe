<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6723561c9802b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\151\x6e\171\137\155\143\x65\x5f\x62\145\x66\157\162\145\137\x69\156\x69\x74", [$this, "\141\x63\x61\x75\x77\x65\x71\171\x79\165\x67\x77\x69\x73\x71\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\155\143\145\x5f\x62\165\x74\x74\157\x6e\163", [$this, "\141\x73\141\x71\145\147\145\167\x75\151\161\145\x65\x63\165\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\157\x6e\164\x73\151\172\x65\163\145\154\145\x63\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\x6f\156\x74\x73\x69\172\145\x5f\146\157\162\x6d\x61\x74\163"] = "\70\160\170\40\x31\60\x70\x78\40\x31\x32\160\x78\x20\x31\x34\160\170\x20\x31\x36\x70\x78\x20\62\x30\160\170\x20\62\64\160\170\40\x32\x38\160\170\x20\x33\x32\160\170\x20\x33\x36\160\170\x20\64\70\160\x78\x20\x36\x30\x70\170\40\x37\62\160\x78\40\x39\x36\160\170"; return $iwsskoiwswyqeuee; } }
