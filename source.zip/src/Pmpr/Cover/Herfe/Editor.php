<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6723571d95406             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\x69\156\x79\137\155\143\145\137\142\x65\146\x6f\162\x65\x5f\x69\156\x69\x74", [$this, "\x61\143\x61\x75\x77\x65\x71\171\x79\165\147\x77\151\x73\x71\143"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\x63\x65\x5f\x62\165\164\164\x6f\x6e\x73", [$this, "\141\x73\x61\x71\x65\147\145\167\x75\x69\161\x65\x65\x63\165\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\157\156\164\x73\151\172\145\x73\x65\x6c\x65\x63\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\157\156\x74\x73\151\172\145\x5f\146\x6f\x72\155\141\164\163"] = "\70\x70\x78\40\x31\x30\160\x78\40\61\62\160\x78\40\x31\64\x70\x78\x20\x31\x36\160\x78\40\62\60\160\170\40\62\x34\160\x78\x20\x32\x38\x70\170\x20\x33\62\160\170\40\x33\x36\x70\x78\x20\x34\70\160\x78\40\66\x30\160\x78\x20\67\x32\x70\x78\40\71\66\160\x78"; return $iwsskoiwswyqeuee; } }
