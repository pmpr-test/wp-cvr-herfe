<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675f1d01c63fa             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\151\x6e\171\x5f\155\143\x65\x5f\x62\x65\146\157\162\145\137\151\x6e\151\x74", [$this, "\141\x63\x61\165\167\x65\x71\x79\171\165\147\167\x69\x73\161\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\155\x63\x65\x5f\x62\x75\164\164\157\x6e\163", [$this, "\x61\163\141\161\145\147\x65\x77\x75\x69\161\145\x65\143\165\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\x6f\156\164\x73\151\x7a\x65\x73\x65\x6c\x65\x63\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\157\156\x74\163\x69\x7a\145\137\146\x6f\162\155\x61\164\x73"] = "\x38\160\170\40\x31\x30\x70\x78\40\x31\62\160\x78\x20\61\x34\x70\x78\40\x31\66\160\170\40\62\x30\160\x78\x20\62\x34\160\x78\x20\x32\x38\160\170\x20\x33\62\x70\x78\40\x33\x36\160\x78\x20\x34\x38\160\x78\x20\66\x30\160\170\x20\67\62\160\x78\40\x39\x36\x70\170"; return $iwsskoiwswyqeuee; } }
