<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6c19c25c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\151\x6e\x79\137\x6d\143\x65\x5f\x62\145\146\157\162\145\x5f\x69\156\x69\164", [$this, "\141\x63\141\165\167\x65\161\171\x79\165\x67\x77\x69\163\161\143"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\x63\145\x5f\142\x75\164\x74\x6f\156\163", [$this, "\141\163\x61\x71\145\147\145\x77\x75\x69\x71\145\145\x63\x75\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\157\x6e\x74\163\151\172\145\163\x65\x6c\145\x63\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\157\156\164\163\151\x7a\x65\137\146\157\162\155\141\x74\163"] = "\x38\160\x78\x20\61\x30\x70\x78\x20\x31\x32\160\x78\40\x31\64\160\x78\x20\x31\66\160\170\x20\62\x30\x70\x78\40\62\x34\x70\170\40\62\x38\x70\x78\x20\63\62\160\170\x20\63\x36\x70\170\x20\64\70\x70\x78\40\66\x30\160\170\x20\67\62\x70\x78\40\71\x36\x70\170"; return $iwsskoiwswyqeuee; } }
