<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672f20b05f84c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\151\x6e\x79\x5f\x6d\x63\x65\x5f\x62\x65\146\157\x72\145\137\151\156\151\164", [$this, "\x61\x63\x61\165\167\145\x71\171\171\165\x67\x77\151\x73\x71\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\155\143\x65\x5f\142\165\x74\164\157\156\x73", [$this, "\x61\x73\141\161\x65\x67\145\x77\165\151\161\145\x65\x63\x75\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\x6f\x6e\164\x73\151\172\145\163\145\x6c\145\x63\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\157\156\x74\x73\x69\x7a\x65\137\x66\x6f\162\155\x61\x74\163"] = "\70\x70\170\40\61\60\x70\x78\x20\61\62\160\x78\40\61\x34\160\x78\x20\x31\66\160\170\40\x32\60\x70\170\40\62\x34\160\x78\40\62\x38\x70\170\40\x33\x32\x70\170\x20\63\x36\160\x78\x20\x34\x38\x70\x78\x20\x36\60\x70\x78\x20\67\x32\160\170\40\71\66\160\x78"; return $iwsskoiwswyqeuee; } }
