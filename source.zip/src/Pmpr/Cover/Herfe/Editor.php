<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d8c7dc1c6             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\151\156\171\137\x6d\143\x65\x5f\142\145\x66\x6f\x72\145\x5f\x69\156\151\164", [$this, "\x61\143\141\165\x77\x65\161\171\171\x75\147\167\151\x73\161\143"], PHP_INT_MAX)->cecaguuoecmccuse("\155\x63\x65\x5f\x62\x75\x74\x74\157\156\x73", [$this, "\141\x73\x61\x71\145\x67\145\167\165\151\161\145\145\x63\x75\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\x6f\x6e\x74\163\x69\x7a\x65\x73\x65\x6c\145\143\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\x6f\x6e\164\163\x69\x7a\145\137\x66\157\162\x6d\141\164\x73"] = "\x38\160\170\40\x31\60\160\170\x20\61\62\x70\170\40\61\64\160\170\40\61\x36\x70\170\40\x32\60\x70\x78\40\62\64\x70\x78\40\62\70\160\x78\40\x33\62\x70\x78\x20\x33\66\160\170\x20\x34\x38\160\170\x20\x36\x30\160\170\40\x37\x32\160\x78\x20\x39\66\160\170"; return $iwsskoiwswyqeuee; } }
