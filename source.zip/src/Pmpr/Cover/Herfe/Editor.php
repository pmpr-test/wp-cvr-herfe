<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716beb75287c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\151\156\171\x5f\x6d\143\145\x5f\x62\x65\146\x6f\162\145\137\151\x6e\x69\x74", [$this, "\141\143\x61\x75\x77\x65\x71\x79\x79\x75\147\x77\x69\x73\x71\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\155\143\145\137\x62\165\164\164\157\156\163", [$this, "\x61\163\141\161\145\x67\x65\x77\165\x69\x71\145\145\x63\x75\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\157\156\164\x73\151\x7a\145\163\x65\x6c\145\143\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\157\x6e\164\x73\x69\172\x65\x5f\x66\x6f\162\155\141\164\x73"] = "\x38\160\x78\x20\x31\60\x70\170\x20\x31\x32\160\170\40\x31\64\x70\x78\40\61\66\160\x78\40\62\60\160\x78\x20\62\x34\x70\x78\40\62\x38\x70\170\x20\x33\62\x70\170\x20\x33\x36\160\x78\x20\x34\x38\160\170\40\x36\x30\160\170\40\x37\62\160\170\40\71\66\x70\x78"; return $iwsskoiwswyqeuee; } }
