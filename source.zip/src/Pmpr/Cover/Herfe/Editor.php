<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7736f3f8             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\x69\156\171\x5f\x6d\143\x65\137\x62\x65\146\x6f\162\x65\x5f\151\156\151\x74", [$this, "\141\143\x61\165\167\145\x71\x79\171\x75\147\167\151\163\161\143"], PHP_INT_MAX)->cecaguuoecmccuse("\155\x63\x65\137\x62\165\x74\164\157\156\x73", [$this, "\x61\x73\141\161\x65\x67\x65\167\165\151\161\145\145\143\x75\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\157\x6e\x74\163\151\172\x65\163\145\x6c\x65\143\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\x6f\156\x74\163\151\172\145\x5f\x66\x6f\x72\x6d\141\x74\x73"] = "\70\160\170\x20\61\x30\160\170\x20\x31\x32\x70\170\x20\x31\64\x70\x78\40\61\66\160\x78\x20\x32\60\160\170\x20\62\x34\160\x78\40\62\70\x70\x78\40\x33\x32\x70\170\x20\x33\x36\160\170\x20\64\70\160\170\40\x36\60\160\x78\x20\x37\x32\x70\x78\x20\x39\66\x70\170"; return $iwsskoiwswyqeuee; } }
