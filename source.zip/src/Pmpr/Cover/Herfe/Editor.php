<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670ed81273dbc             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\x69\156\x79\137\x6d\143\x65\137\x62\x65\x66\x6f\x72\x65\137\151\x6e\x69\164", [$this, "\x61\143\x61\165\x77\145\161\x79\x79\165\147\x77\151\x73\161\143"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\143\x65\x5f\142\165\x74\x74\157\156\163", [$this, "\x61\163\x61\161\x65\x67\x65\x77\165\x69\161\x65\x65\143\x75\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\157\156\164\x73\151\172\x65\x73\x65\154\145\143\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\x6f\x6e\x74\x73\x69\x7a\145\x5f\146\x6f\x72\x6d\x61\x74\x73"] = "\70\x70\x78\40\61\60\x70\x78\40\x31\x32\x70\x78\x20\x31\64\x70\170\40\61\66\x70\170\40\62\x30\160\x78\x20\62\x34\x70\x78\x20\62\70\x70\x78\x20\x33\62\x70\170\40\63\66\160\x78\40\x34\x38\x70\x78\x20\66\x30\x70\170\40\x37\x32\x70\170\40\71\x36\x70\170"; return $iwsskoiwswyqeuee; } }
