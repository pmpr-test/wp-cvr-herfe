<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670520e2dd031             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\151\x6e\x79\x5f\155\143\145\x5f\x62\x65\x66\157\x72\145\x5f\x69\x6e\151\x74", [$this, "\x61\x63\x61\x75\x77\145\x71\171\171\165\147\x77\x69\x73\161\143"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\x63\145\137\x62\165\164\x74\x6f\x6e\163", [$this, "\x61\163\x61\161\145\147\x65\167\165\151\161\x65\x65\x63\165\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\x6f\156\x74\x73\151\172\145\x73\x65\154\145\143\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\157\156\164\x73\x69\172\145\137\146\157\x72\155\141\164\163"] = "\x38\x70\x78\40\x31\x30\x70\170\x20\61\62\160\x78\40\61\x34\x70\x78\x20\61\x36\160\x78\x20\x32\x30\x70\170\40\x32\x34\x70\170\x20\62\x38\160\170\40\x33\62\x70\x78\x20\63\x36\160\x78\x20\x34\70\160\170\40\x36\60\160\170\40\67\x32\x70\170\x20\71\66\x70\x78"; return $iwsskoiwswyqeuee; } }
