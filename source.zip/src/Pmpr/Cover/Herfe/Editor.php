<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae860947df             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\x69\156\x79\137\155\x63\x65\137\x62\145\x66\x6f\x72\145\137\x69\156\x69\164", [$this, "\x61\x63\x61\x75\167\x65\x71\171\171\165\147\167\x69\163\x71\143"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\143\145\137\142\165\x74\164\x6f\156\163", [$this, "\x61\x73\141\161\x65\147\x65\167\165\x69\x71\145\145\143\165\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\157\x6e\x74\x73\151\x7a\x65\163\145\154\x65\143\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\x6f\156\164\x73\151\x7a\145\137\146\157\162\155\x61\x74\163"] = "\x38\160\x78\x20\x31\60\160\170\x20\61\62\x70\170\40\x31\x34\160\170\40\61\66\160\x78\40\62\60\x70\x78\40\62\x34\x70\170\x20\x32\70\160\x78\x20\x33\x32\160\170\40\x33\x36\x70\170\x20\64\x38\x70\170\x20\x36\x30\160\x78\40\67\x32\x70\170\x20\x39\x36\x70\170"; return $iwsskoiwswyqeuee; } }
