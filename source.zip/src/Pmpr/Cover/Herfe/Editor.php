<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c79ea27654             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse('tiny_mce_before_init', [$this, 'acauweqyyugwisqc'], PHP_INT_MAX)->cecaguuoecmccuse('mce_buttons', [$this, 'asaqegewuiqeecum'], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = 'fontsizeselect'; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee['fontsize_formats'] = '8px 10px 12px 14px 16px 20px 24px 28px 32px 36px 48px 60px 72px 96px'; return $iwsskoiwswyqeuee; } }
