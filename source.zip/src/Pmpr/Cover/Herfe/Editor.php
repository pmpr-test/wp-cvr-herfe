<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716e3b829921             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\x69\156\x79\x5f\x6d\143\x65\x5f\142\x65\x66\157\162\145\137\151\156\x69\164", [$this, "\x61\x63\141\x75\167\145\x71\x79\x79\165\x67\x77\x69\x73\x71\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\155\x63\x65\x5f\x62\x75\164\164\x6f\x6e\x73", [$this, "\141\163\141\x71\145\147\145\167\x75\x69\x71\x65\145\143\165\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\x6f\156\164\x73\x69\x7a\145\x73\145\x6c\145\x63\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\x6f\x6e\x74\163\151\x7a\145\137\x66\157\x72\155\x61\164\x73"] = "\x38\x70\170\40\x31\60\160\x78\40\61\x32\x70\x78\40\x31\64\x70\x78\x20\61\66\x70\x78\x20\x32\x30\x70\170\40\x32\x34\160\x78\x20\x32\70\160\x78\x20\63\x32\160\x78\40\63\x36\x70\x78\x20\64\x38\160\x78\x20\x36\60\160\170\40\67\62\160\x78\x20\71\66\x70\170"; return $iwsskoiwswyqeuee; } }
