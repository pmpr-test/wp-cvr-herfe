<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716e42069d0c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\151\156\171\x5f\155\143\145\137\142\145\146\157\162\145\137\151\x6e\x69\164", [$this, "\x61\143\141\x75\x77\145\161\x79\171\x75\147\167\x69\163\161\143"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\x63\x65\x5f\x62\165\x74\164\157\x6e\x73", [$this, "\x61\x73\141\x71\x65\x67\x65\167\x75\151\161\x65\145\x63\x75\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\157\156\x74\x73\151\172\145\163\x65\154\x65\x63\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\157\156\164\163\151\172\x65\x5f\146\157\x72\x6d\x61\164\x73"] = "\x38\x70\x78\40\x31\x30\160\x78\x20\61\x32\x70\170\x20\x31\64\x70\x78\40\61\66\x70\170\x20\62\60\160\170\40\62\64\x70\170\40\62\70\x70\170\x20\x33\x32\x70\170\x20\x33\66\160\x78\x20\x34\70\160\x78\40\x36\60\160\x78\40\67\x32\x70\170\40\x39\x36\x70\170"; return $iwsskoiwswyqeuee; } }
