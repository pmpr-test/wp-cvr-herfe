<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd850a130             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\151\x6e\x79\x5f\155\x63\145\x5f\x62\145\146\157\162\x65\x5f\x69\156\x69\x74", [$this, "\141\143\141\x75\167\145\x71\x79\171\165\x67\x77\151\163\x71\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\155\x63\145\137\x62\x75\x74\164\157\156\x73", [$this, "\x61\163\x61\x71\145\147\x65\167\x75\x69\161\145\x65\x63\x75\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\x6f\x6e\164\163\151\x7a\x65\163\x65\154\x65\x63\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\157\156\164\x73\151\172\x65\137\x66\157\162\x6d\x61\164\163"] = "\x38\x70\170\x20\x31\x30\160\x78\x20\x31\x32\160\x78\40\61\x34\x70\x78\40\61\66\160\170\x20\x32\60\160\170\x20\x32\x34\160\170\40\x32\70\160\x78\40\63\62\160\170\40\x33\66\x70\170\x20\x34\x38\160\x78\x20\66\60\x70\170\40\x37\x32\x70\x78\x20\71\66\x70\x78"; return $iwsskoiwswyqeuee; } }
