<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a88ebba2             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\151\x6e\171\137\155\x63\x65\x5f\x62\145\146\x6f\162\145\137\151\156\151\x74", [$this, "\x61\143\x61\165\167\145\161\171\171\165\x67\167\x69\x73\161\143"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\143\x65\137\x62\x75\164\164\x6f\156\x73", [$this, "\141\163\141\x71\x65\147\145\167\x75\x69\x71\145\145\143\165\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\x6f\156\x74\x73\x69\x7a\x65\x73\145\x6c\x65\143\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\x6f\156\x74\163\x69\x7a\x65\137\x66\157\162\155\x61\x74\163"] = "\70\160\170\40\61\60\x70\170\40\x31\x32\160\x78\40\x31\x34\160\170\x20\61\x36\160\x78\40\x32\x30\160\x78\40\x32\64\160\x78\40\62\70\x70\x78\40\x33\62\160\x78\40\x33\x36\x70\x78\x20\64\70\160\170\40\66\x30\x70\x78\x20\x37\x32\x70\170\40\71\66\160\x78"; return $iwsskoiwswyqeuee; } }
