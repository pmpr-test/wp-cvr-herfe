<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716e65b82eec             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\x69\156\x79\x5f\155\143\x65\x5f\142\145\x66\157\162\x65\137\151\156\x69\x74", [$this, "\141\x63\x61\x75\x77\x65\161\x79\171\165\x67\x77\151\163\161\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\155\x63\145\x5f\142\x75\164\164\157\156\x73", [$this, "\141\x73\x61\161\145\147\x65\x77\x75\x69\x71\145\x65\x63\165\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\157\156\x74\163\151\x7a\x65\163\145\x6c\145\x63\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\x6f\x6e\x74\x73\x69\x7a\x65\x5f\x66\x6f\162\x6d\141\x74\x73"] = "\70\160\x78\x20\61\60\160\x78\x20\x31\62\160\x78\40\61\64\160\170\40\x31\x36\x70\170\40\62\x30\x70\x78\x20\62\x34\x70\x78\40\62\70\160\x78\x20\x33\x32\160\170\40\63\x36\x70\170\40\x34\70\x70\170\x20\x36\x30\160\170\x20\x37\62\160\x78\40\71\66\160\170"; return $iwsskoiwswyqeuee; } }
