<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672357a7cf1c9             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\151\156\171\137\x6d\143\x65\137\142\145\146\157\x72\145\x5f\x69\x6e\151\x74", [$this, "\141\x63\141\165\167\145\x71\x79\171\x75\147\167\151\x73\161\143"], PHP_INT_MAX)->cecaguuoecmccuse("\155\x63\145\x5f\142\165\x74\164\157\x6e\163", [$this, "\x61\x73\x61\161\x65\147\145\167\x75\x69\161\x65\145\x63\x75\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\157\156\x74\x73\151\x7a\145\x73\x65\154\145\143\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\157\156\x74\x73\x69\x7a\145\137\x66\157\x72\x6d\141\164\163"] = "\70\160\x78\40\x31\60\160\170\x20\61\62\160\x78\40\x31\64\160\x78\x20\61\x36\x70\x78\40\62\60\160\x78\40\62\x34\x70\x78\40\x32\70\160\x78\40\63\x32\160\170\x20\x33\x36\x70\x78\40\64\x38\160\170\x20\66\x30\160\170\40\67\62\160\x78\x20\x39\x36\x70\170"; return $iwsskoiwswyqeuee; } }
