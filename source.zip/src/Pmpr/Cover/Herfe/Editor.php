<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670cfff9ed68b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\x69\x6e\171\x5f\155\x63\x65\137\142\145\146\x6f\x72\x65\x5f\151\156\151\x74", [$this, "\141\143\x61\165\167\145\161\x79\171\165\147\167\151\163\x71\143"], PHP_INT_MAX)->cecaguuoecmccuse("\155\x63\145\137\x62\165\164\x74\157\x6e\163", [$this, "\141\163\x61\x71\145\147\145\x77\x75\x69\x71\x65\145\x63\x75\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\157\156\164\163\151\172\x65\x73\x65\154\145\143\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\x6f\156\164\163\151\172\145\x5f\146\157\162\155\x61\164\163"] = "\x38\x70\x78\x20\x31\60\160\170\40\x31\62\x70\x78\x20\61\64\160\170\40\61\66\x70\170\x20\62\60\x70\170\x20\62\64\x70\x78\x20\62\x38\x70\170\x20\x33\62\160\170\40\x33\66\x70\170\40\64\70\160\170\x20\66\60\160\170\x20\x37\62\160\170\x20\71\x36\160\x78"; return $iwsskoiwswyqeuee; } }
