<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672357617e71a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\x69\156\171\137\x6d\x63\145\x5f\x62\145\146\x6f\x72\x65\137\151\156\x69\164", [$this, "\x61\143\x61\165\x77\x65\x71\171\x79\165\x67\x77\x69\x73\161\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\143\145\x5f\x62\x75\164\x74\157\156\x73", [$this, "\x61\x73\141\x71\145\147\145\x77\x75\x69\161\145\x65\143\165\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\x6f\156\x74\163\151\x7a\x65\x73\x65\x6c\x65\143\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\157\x6e\x74\163\151\172\145\x5f\146\x6f\162\x6d\x61\x74\163"] = "\70\160\x78\40\61\x30\x70\x78\x20\61\x32\160\170\40\61\64\160\x78\40\61\66\x70\170\40\62\x30\x70\x78\x20\62\64\160\170\x20\62\x38\x70\x78\40\63\x32\160\x78\40\x33\66\x70\170\x20\64\x38\160\170\40\x36\60\160\x78\x20\67\62\x70\170\x20\71\66\x70\x78"; return $iwsskoiwswyqeuee; } }
