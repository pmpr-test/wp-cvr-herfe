<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6786e8493ce65             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Cover\Herfe\Traits\CommonTrait; abstract class Container extends BaseClass { use CommonTrait; }
