<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68b43fc48d6d5             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Page; use Pmpr\Cover\Herfe\Container; class Page extends Container { public function mameiwsayuyquoeq() { Team::symcgieuakksimmu(); About::symcgieuakksimmu(); } }
