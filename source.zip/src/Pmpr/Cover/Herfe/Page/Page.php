<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7736f3f8             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Page; use Pmpr\Cover\Herfe\Container; class Page extends Container { public function mameiwsayuyquoeq() { Team::symcgieuakksimmu(); About::symcgieuakksimmu(); } }
