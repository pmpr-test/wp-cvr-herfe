<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc06044c94             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Page; use Pmpr\Common\Foundation\Interfaces\Constants; abstract class AbstractAbout extends Common { public function __construct() { $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function rsysgcucogueguuk() : array { return [Constants::yusuiaeueqwieqqq => [About::symcgieuakksimmu()->kyqakacqeumicgag(), Team::symcgieuakksimmu()->kyqakacqeumicgag()]]; } }
