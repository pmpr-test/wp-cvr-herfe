<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716e42069d0c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Page; class Team extends AbstractAbout { public function __construct() { $this->slug = "\164\145\141\155"; $this->parent = About::symcgieuakksimmu(); parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x54\x65\141\x6d", PR__CVR__HERFE); } }
