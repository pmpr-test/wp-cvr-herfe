<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7736f3f8             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Page; class Team extends AbstractAbout { public function __construct() { $this->slug = "\x74\145\x61\155"; $this->parent = About::symcgieuakksimmu(); parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x54\x65\141\155", PR__CVR__HERFE); } }
