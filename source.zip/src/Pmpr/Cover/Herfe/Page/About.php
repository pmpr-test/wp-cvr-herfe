<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6953da7d56ee3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Page; class About extends AbstractAbout { public function __construct() { $this->slug = 'about'; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __('About', PR__CVR__HERFE); } }
