<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6723561c9802b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Page; class About extends AbstractAbout { public function __construct() { $this->slug = "\141\x62\157\x75\x74"; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x41\x62\x6f\165\x74", PR__CVR__HERFE); } }
