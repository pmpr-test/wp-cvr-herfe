<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672f20b05f84c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Page; class About extends AbstractAbout { public function __construct() { $this->slug = "\141\142\157\x75\164"; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\101\x62\x6f\165\164", PR__CVR__HERFE); } }
