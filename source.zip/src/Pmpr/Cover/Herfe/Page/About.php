<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46ad485fc             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Page; class About extends AbstractAbout { public function __construct() { $this->slug = "\x61\142\x6f\165\164"; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\101\142\157\x75\164", PR__CVR__HERFE); } }
