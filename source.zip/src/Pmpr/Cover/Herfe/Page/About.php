<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             676e6b402df87             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Page; class About extends AbstractAbout { public function __construct() { $this->slug = "\x61\142\157\x75\164"; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\101\142\x6f\x75\x74", PR__CVR__HERFE); } }
