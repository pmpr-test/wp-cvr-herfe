<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68b43fc48d6d5             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Navigation\Walker; use Pmpr\Common\Cover\Navigation\Walker as BaseClass; class Walker extends BaseClass { }
