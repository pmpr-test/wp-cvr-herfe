<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670ed81273dbc             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Textarea; class Rating extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x72\141\164\151\x6e\147\137\146\145\145\144\142\x61\143\153\x5f\146\157\x72\x6d\x5f\146\151\x65\154\x64\x73", [$this, "\155\x65\143\147\x61\x61\143\x79\161\165\157\x75\147\x75\x65\x67"]); } public function mecgaacyquougueg(array $ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $momcykaoccoymeig => $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field) { if ($aiowsaccomcoikus instanceof Button) { $aiowsaccomcoikus->qigsyyqgewgskemg("\155\x61\151\x6e\55\x61\x63\164\x69\x6f\156")->kakecegieeqyyayu()->qigsyyqgewgskemg("\164\x65\x78\x74\x2d\x6c\x65\146\164"); } else { if ($aiowsaccomcoikus instanceof Textarea) { $aiowsaccomcoikus->macygmcekgqwmcwk()->qigsyyqgewgskemg("\142\147\x2d\167\x68\x69\x74\145"); } $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\142\x2d\65"); } } $ikgwqyuyckaewsow[$momcykaoccoymeig] = $aiowsaccomcoikus; } return $ikgwqyuyckaewsow; } }
