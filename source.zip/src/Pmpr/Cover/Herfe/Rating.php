<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716e65b82eec             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Textarea; class Rating extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\162\x61\164\x69\x6e\x67\137\146\x65\x65\x64\142\x61\x63\153\137\146\x6f\x72\155\x5f\146\x69\x65\x6c\x64\163", [$this, "\155\x65\x63\x67\x61\x61\143\171\161\165\157\165\147\165\x65\147"]); } public function mecgaacyquougueg(array $ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $momcykaoccoymeig => $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field) { if ($aiowsaccomcoikus instanceof Button) { $aiowsaccomcoikus->qigsyyqgewgskemg("\155\141\x69\x6e\x2d\x61\143\164\x69\x6f\156")->kakecegieeqyyayu()->qigsyyqgewgskemg("\164\x65\x78\164\x2d\154\145\146\164"); } else { if ($aiowsaccomcoikus instanceof Textarea) { $aiowsaccomcoikus->macygmcekgqwmcwk()->qigsyyqgewgskemg("\142\147\55\167\150\x69\164\145"); } $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\x62\x2d\x35"); } } $ikgwqyuyckaewsow[$momcykaoccoymeig] = $aiowsaccomcoikus; } return $ikgwqyuyckaewsow; } }
