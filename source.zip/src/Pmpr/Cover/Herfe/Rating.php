<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716beb75287c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Textarea; class Rating extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\162\141\164\x69\x6e\x67\137\x66\145\x65\144\x62\x61\x63\x6b\137\x66\x6f\x72\155\137\x66\x69\145\x6c\x64\x73", [$this, "\x6d\145\143\x67\x61\x61\143\x79\161\x75\157\x75\x67\x75\145\x67"]); } public function mecgaacyquougueg(array $ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $momcykaoccoymeig => $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field) { if ($aiowsaccomcoikus instanceof Button) { $aiowsaccomcoikus->qigsyyqgewgskemg("\155\141\151\156\55\x61\143\164\151\157\156")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x74\145\170\164\x2d\x6c\x65\146\x74"); } else { if ($aiowsaccomcoikus instanceof Textarea) { $aiowsaccomcoikus->macygmcekgqwmcwk()->qigsyyqgewgskemg("\142\x67\55\167\x68\151\x74\145"); } $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\x62\x2d\x35"); } } $ikgwqyuyckaewsow[$momcykaoccoymeig] = $aiowsaccomcoikus; } return $ikgwqyuyckaewsow; } }
