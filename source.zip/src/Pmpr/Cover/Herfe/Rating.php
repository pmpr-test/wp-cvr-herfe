<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9fdf1fbfc             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Textarea; class Rating extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\162\x61\x74\x69\156\x67\x5f\146\145\145\144\142\x61\143\153\137\x66\x6f\162\155\x5f\146\151\x65\x6c\x64\163", [$this, "\x6d\x65\143\x67\141\x61\143\x79\x71\165\157\x75\147\165\145\x67"]); } public function mecgaacyquougueg(array $ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $momcykaoccoymeig => $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field) { if ($aiowsaccomcoikus instanceof Button) { $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\x61\x69\156\x2d\141\143\x74\x69\x6f\156")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x74\x65\170\x74\55\154\145\146\164"); } else { if ($aiowsaccomcoikus instanceof Textarea) { $aiowsaccomcoikus->macygmcekgqwmcwk()->qigsyyqgewgskemg("\x62\147\55\167\x68\151\164\145"); } $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\142\55\65"); } } $ikgwqyuyckaewsow[$momcykaoccoymeig] = $aiowsaccomcoikus; } return $ikgwqyuyckaewsow; } }
