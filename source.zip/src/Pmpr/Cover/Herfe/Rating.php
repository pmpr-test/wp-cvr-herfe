<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675f1d01c63fa             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Textarea; class Rating extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\162\x61\164\x69\x6e\147\x5f\x66\x65\145\x64\142\141\x63\153\x5f\x66\157\x72\x6d\137\146\x69\145\x6c\x64\x73", [$this, "\x6d\x65\x63\147\x61\x61\x63\171\161\165\157\x75\x67\x75\x65\x67"]); } public function mecgaacyquougueg(array $ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $momcykaoccoymeig => $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field) { if ($aiowsaccomcoikus instanceof Button) { $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\x61\151\x6e\x2d\x61\x63\x74\151\157\x6e")->kakecegieeqyyayu()->qigsyyqgewgskemg("\164\x65\170\164\x2d\x6c\x65\x66\164"); } else { if ($aiowsaccomcoikus instanceof Textarea) { $aiowsaccomcoikus->macygmcekgqwmcwk()->qigsyyqgewgskemg("\142\x67\x2d\167\x68\151\164\x65"); } $aiowsaccomcoikus->qigsyyqgewgskemg("\155\142\x2d\65"); } } $ikgwqyuyckaewsow[$momcykaoccoymeig] = $aiowsaccomcoikus; } return $ikgwqyuyckaewsow; } }
