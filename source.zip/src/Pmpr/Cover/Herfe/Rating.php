<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670cfff9ed68b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Textarea; class Rating extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x72\141\164\151\x6e\147\x5f\x66\145\x65\x64\142\x61\143\153\137\x66\157\162\x6d\x5f\146\x69\x65\x6c\144\x73", [$this, "\x6d\145\x63\x67\141\141\x63\x79\x71\x75\x6f\x75\147\165\x65\147"]); } public function mecgaacyquougueg(array $ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $momcykaoccoymeig => $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field) { if ($aiowsaccomcoikus instanceof Button) { $aiowsaccomcoikus->qigsyyqgewgskemg("\155\x61\151\156\x2d\141\143\164\x69\x6f\156")->kakecegieeqyyayu()->qigsyyqgewgskemg("\164\145\170\x74\55\x6c\x65\146\164"); } else { if ($aiowsaccomcoikus instanceof Textarea) { $aiowsaccomcoikus->macygmcekgqwmcwk()->qigsyyqgewgskemg("\x62\x67\55\167\150\x69\164\x65"); } $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\142\x2d\65"); } } $ikgwqyuyckaewsow[$momcykaoccoymeig] = $aiowsaccomcoikus; } return $ikgwqyuyckaewsow; } }
