<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             676e6b402df87             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Textarea; class Rating extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\162\141\x74\151\x6e\147\137\146\x65\145\144\x62\x61\x63\153\x5f\146\157\162\x6d\x5f\x66\x69\x65\154\144\x73", [$this, "\155\x65\143\147\x61\x61\x63\171\161\x75\x6f\x75\147\x75\x65\x67"]); } public function mecgaacyquougueg(array $ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $momcykaoccoymeig => $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field) { if ($aiowsaccomcoikus instanceof Button) { $aiowsaccomcoikus->qigsyyqgewgskemg("\155\x61\x69\156\x2d\141\143\164\151\157\156")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x74\145\170\164\x2d\154\145\146\x74"); } else { if ($aiowsaccomcoikus instanceof Textarea) { $aiowsaccomcoikus->macygmcekgqwmcwk()->qigsyyqgewgskemg("\x62\x67\55\167\x68\x69\164\x65"); } $aiowsaccomcoikus->qigsyyqgewgskemg("\155\x62\x2d\65"); } } $ikgwqyuyckaewsow[$momcykaoccoymeig] = $aiowsaccomcoikus; } return $ikgwqyuyckaewsow; } }
