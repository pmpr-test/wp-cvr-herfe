<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d8c7dc1c6             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Textarea; class Rating extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\162\141\164\151\156\147\137\146\x65\145\x64\x62\x61\x63\153\x5f\146\157\x72\155\x5f\x66\x69\145\154\x64\x73", [$this, "\155\145\x63\147\x61\141\x63\171\161\x75\x6f\165\147\165\145\147"]); } public function mecgaacyquougueg(array $ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $momcykaoccoymeig => $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field) { if ($aiowsaccomcoikus instanceof Button) { $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\x61\x69\156\x2d\x61\x63\164\151\157\156")->kakecegieeqyyayu()->qigsyyqgewgskemg("\164\145\x78\164\55\x6c\x65\146\164"); } else { if ($aiowsaccomcoikus instanceof Textarea) { $aiowsaccomcoikus->macygmcekgqwmcwk()->qigsyyqgewgskemg("\x62\x67\x2d\x77\x68\151\x74\x65"); } $aiowsaccomcoikus->qigsyyqgewgskemg("\155\x62\x2d\x35"); } } $ikgwqyuyckaewsow[$momcykaoccoymeig] = $aiowsaccomcoikus; } return $ikgwqyuyckaewsow; } }
