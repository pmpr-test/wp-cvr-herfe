<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6786e8493ce65             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Textarea; class Rating extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x72\x61\x74\151\x6e\x67\x5f\146\145\145\144\142\141\x63\153\x5f\x66\157\162\155\x5f\146\x69\x65\x6c\144\163", [$this, "\x6d\x65\x63\147\141\x61\143\x79\x71\165\x6f\165\x67\165\145\147"]); } public function mecgaacyquougueg(array $ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $momcykaoccoymeig => $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field) { if ($aiowsaccomcoikus instanceof Button) { $aiowsaccomcoikus->qigsyyqgewgskemg("\155\x61\151\x6e\x2d\141\143\164\151\157\156")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x74\145\x78\x74\55\154\145\x66\164"); } else { if ($aiowsaccomcoikus instanceof Textarea) { $aiowsaccomcoikus->macygmcekgqwmcwk()->qigsyyqgewgskemg("\142\147\55\x77\150\x69\164\x65"); } $aiowsaccomcoikus->qigsyyqgewgskemg("\155\142\x2d\x35"); } } $ikgwqyuyckaewsow[$momcykaoccoymeig] = $aiowsaccomcoikus; } return $ikgwqyuyckaewsow; } }
