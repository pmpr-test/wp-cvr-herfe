<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46ad485fc             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Textarea; class Rating extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x72\x61\x74\x69\156\x67\137\x66\145\x65\144\x62\141\143\x6b\137\146\157\162\155\x5f\x66\x69\145\154\144\163", [$this, "\x6d\x65\143\147\141\141\143\x79\161\x75\x6f\x75\x67\x75\145\147"]); } public function mecgaacyquougueg(array $ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $momcykaoccoymeig => $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field) { if ($aiowsaccomcoikus instanceof Button) { $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\141\151\156\x2d\x61\x63\164\151\x6f\156")->kakecegieeqyyayu()->qigsyyqgewgskemg("\164\x65\170\x74\55\154\145\146\164"); } else { if ($aiowsaccomcoikus instanceof Textarea) { $aiowsaccomcoikus->macygmcekgqwmcwk()->qigsyyqgewgskemg("\142\x67\x2d\167\x68\x69\x74\145"); } $aiowsaccomcoikus->qigsyyqgewgskemg("\155\142\55\x35"); } } $ikgwqyuyckaewsow[$momcykaoccoymeig] = $aiowsaccomcoikus; } return $ikgwqyuyckaewsow; } }
