<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716e3b829921             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Textarea; class Rating extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x72\x61\164\x69\156\147\x5f\x66\x65\145\x64\142\141\143\153\x5f\x66\157\162\155\x5f\146\151\145\154\144\163", [$this, "\155\x65\x63\147\141\141\143\171\x71\165\x6f\x75\147\x75\x65\x67"]); } public function mecgaacyquougueg(array $ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $momcykaoccoymeig => $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field) { if ($aiowsaccomcoikus instanceof Button) { $aiowsaccomcoikus->qigsyyqgewgskemg("\155\141\151\x6e\x2d\141\x63\x74\151\157\x6e")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x74\x65\170\164\55\154\x65\x66\x74"); } else { if ($aiowsaccomcoikus instanceof Textarea) { $aiowsaccomcoikus->macygmcekgqwmcwk()->qigsyyqgewgskemg("\x62\147\55\x77\150\151\164\145"); } $aiowsaccomcoikus->qigsyyqgewgskemg("\155\142\55\x35"); } } $ikgwqyuyckaewsow[$momcykaoccoymeig] = $aiowsaccomcoikus; } return $ikgwqyuyckaewsow; } }
