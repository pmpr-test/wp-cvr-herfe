<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6c19c25c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Textarea; class Rating extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\162\x61\164\x69\156\147\137\146\x65\x65\x64\x62\141\143\x6b\137\146\157\x72\155\137\x66\151\x65\x6c\x64\x73", [$this, "\x6d\x65\x63\x67\x61\x61\x63\x79\x71\x75\x6f\x75\147\165\145\147"]); } public function mecgaacyquougueg(array $ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $momcykaoccoymeig => $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field) { if ($aiowsaccomcoikus instanceof Button) { $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\x61\151\x6e\55\141\143\164\151\x6f\x6e")->kakecegieeqyyayu()->qigsyyqgewgskemg("\164\145\170\164\x2d\x6c\145\146\x74"); } else { if ($aiowsaccomcoikus instanceof Textarea) { $aiowsaccomcoikus->macygmcekgqwmcwk()->qigsyyqgewgskemg("\142\147\55\167\x68\151\x74\x65"); } $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\142\55\x35"); } } $ikgwqyuyckaewsow[$momcykaoccoymeig] = $aiowsaccomcoikus; } return $ikgwqyuyckaewsow; } }
