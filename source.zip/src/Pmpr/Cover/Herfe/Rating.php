<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672357617e71a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Textarea; class Rating extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\162\x61\164\x69\156\x67\137\146\x65\x65\x64\142\141\143\153\137\x66\x6f\162\x6d\x5f\x66\151\x65\x6c\144\x73", [$this, "\x6d\145\143\147\141\x61\x63\171\161\x75\x6f\x75\x67\x75\145\x67"]); } public function mecgaacyquougueg(array $ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $momcykaoccoymeig => $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field) { if ($aiowsaccomcoikus instanceof Button) { $aiowsaccomcoikus->qigsyyqgewgskemg("\155\141\151\156\55\x61\143\x74\x69\x6f\x6e")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x74\x65\x78\x74\55\x6c\x65\x66\x74"); } else { if ($aiowsaccomcoikus instanceof Textarea) { $aiowsaccomcoikus->macygmcekgqwmcwk()->qigsyyqgewgskemg("\142\x67\55\x77\150\x69\x74\x65"); } $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\142\55\65"); } } $ikgwqyuyckaewsow[$momcykaoccoymeig] = $aiowsaccomcoikus; } return $ikgwqyuyckaewsow; } }
