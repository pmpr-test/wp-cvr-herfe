<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67052f2951511             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Textarea; class Rating extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\162\x61\164\x69\x6e\x67\x5f\x66\x65\x65\144\x62\141\x63\x6b\x5f\x66\x6f\x72\155\x5f\146\x69\x65\x6c\x64\163", [$this, "\x6d\145\x63\147\x61\141\143\171\x71\165\x6f\165\x67\165\x65\x67"]); } public function mecgaacyquougueg(array $ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $momcykaoccoymeig => $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field) { if ($aiowsaccomcoikus instanceof Button) { $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\x61\x69\156\x2d\x61\143\164\151\157\156")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x74\x65\x78\164\55\154\145\146\x74"); } else { if ($aiowsaccomcoikus instanceof Textarea) { $aiowsaccomcoikus->macygmcekgqwmcwk()->qigsyyqgewgskemg("\142\147\x2d\167\150\x69\164\145"); } $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\x62\x2d\x35"); } } $ikgwqyuyckaewsow[$momcykaoccoymeig] = $aiowsaccomcoikus; } return $ikgwqyuyckaewsow; } }
