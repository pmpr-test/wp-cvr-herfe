<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc06044c94             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Textarea; class Rating extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\162\x61\x74\151\x6e\x67\x5f\146\x65\x65\144\142\x61\143\x6b\137\x66\x6f\162\155\x5f\146\151\145\x6c\x64\163", [$this, "\x6d\145\143\x67\x61\x61\x63\x79\x71\165\157\x75\147\165\145\x67"]); } public function mecgaacyquougueg(array $ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $momcykaoccoymeig => $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field) { if ($aiowsaccomcoikus instanceof Button) { $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\x61\151\156\x2d\141\x63\164\x69\157\156")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x74\145\170\164\x2d\154\x65\146\164"); } else { if ($aiowsaccomcoikus instanceof Textarea) { $aiowsaccomcoikus->macygmcekgqwmcwk()->qigsyyqgewgskemg("\x62\147\55\167\x68\x69\164\145"); } $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\142\x2d\x35"); } } $ikgwqyuyckaewsow[$momcykaoccoymeig] = $aiowsaccomcoikus; } return $ikgwqyuyckaewsow; } }
