<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716e5f3e0948             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Textarea; class Rating extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\162\x61\x74\151\x6e\147\137\146\x65\x65\x64\142\141\x63\153\137\146\x6f\x72\x6d\137\146\151\145\x6c\x64\163", [$this, "\155\145\x63\147\x61\141\143\x79\x71\165\x6f\165\147\x75\x65\x67"]); } public function mecgaacyquougueg(array $ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $momcykaoccoymeig => $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field) { if ($aiowsaccomcoikus instanceof Button) { $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\141\151\x6e\x2d\x61\143\x74\151\157\156")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x74\145\x78\x74\55\x6c\x65\x66\164"); } else { if ($aiowsaccomcoikus instanceof Textarea) { $aiowsaccomcoikus->macygmcekgqwmcwk()->qigsyyqgewgskemg("\142\147\55\x77\x68\x69\x74\145"); } $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\x62\x2d\x35"); } } $ikgwqyuyckaewsow[$momcykaoccoymeig] = $aiowsaccomcoikus; } return $ikgwqyuyckaewsow; } }
