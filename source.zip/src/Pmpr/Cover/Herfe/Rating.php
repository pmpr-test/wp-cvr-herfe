<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a88ebba2             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Textarea; class Rating extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x72\x61\164\x69\156\147\x5f\146\145\x65\144\142\x61\x63\153\x5f\x66\157\x72\x6d\x5f\146\x69\x65\x6c\x64\x73", [$this, "\155\145\143\x67\x61\141\143\x79\161\165\157\165\147\165\145\147"]); } public function mecgaacyquougueg(array $ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $momcykaoccoymeig => $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field) { if ($aiowsaccomcoikus instanceof Button) { $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\x61\151\156\x2d\x61\x63\164\x69\x6f\x6e")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x74\145\x78\164\x2d\x6c\145\x66\164"); } else { if ($aiowsaccomcoikus instanceof Textarea) { $aiowsaccomcoikus->macygmcekgqwmcwk()->qigsyyqgewgskemg("\x62\147\x2d\167\150\x69\x74\x65"); } $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\142\55\x35"); } } $ikgwqyuyckaewsow[$momcykaoccoymeig] = $aiowsaccomcoikus; } return $ikgwqyuyckaewsow; } }
