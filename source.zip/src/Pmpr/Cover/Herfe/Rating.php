<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6723561c9802b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Textarea; class Rating extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x72\141\164\x69\x6e\x67\137\x66\x65\145\144\142\141\x63\x6b\137\x66\157\162\155\x5f\146\x69\145\x6c\x64\163", [$this, "\155\x65\143\147\x61\141\143\171\x71\165\x6f\165\147\165\x65\147"]); } public function mecgaacyquougueg(array $ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $momcykaoccoymeig => $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field) { if ($aiowsaccomcoikus instanceof Button) { $aiowsaccomcoikus->qigsyyqgewgskemg("\155\x61\151\x6e\55\141\x63\164\151\157\x6e")->kakecegieeqyyayu()->qigsyyqgewgskemg("\164\145\x78\164\x2d\154\x65\146\x74"); } else { if ($aiowsaccomcoikus instanceof Textarea) { $aiowsaccomcoikus->macygmcekgqwmcwk()->qigsyyqgewgskemg("\x62\x67\x2d\167\x68\x69\x74\x65"); } $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\142\x2d\x35"); } } $ikgwqyuyckaewsow[$momcykaoccoymeig] = $aiowsaccomcoikus; } return $ikgwqyuyckaewsow; } }
