<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6990793fe03e7             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
