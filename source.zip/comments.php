<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c7c671551b             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
