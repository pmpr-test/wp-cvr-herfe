<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6953d9d52b9ca             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
