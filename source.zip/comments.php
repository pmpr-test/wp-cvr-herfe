<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46ad485fc             |
    |_______________________________________|
*/
 pmpr_do_action("\162\x65\x6e\x64\x65\x72\x5f\x63\x6f\x6d\155\145\x6e\164\x73");
