<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e4dd2e268a5             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
