<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             681fd07bd1332             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
