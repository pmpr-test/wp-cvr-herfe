<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c79ea27654             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
