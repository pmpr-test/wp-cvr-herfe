<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc702653573             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
