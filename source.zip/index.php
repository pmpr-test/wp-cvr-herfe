<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670cfff9ed68b             |
    |_______________________________________|
*/
 pmpr_do_action("\151\x6e\x69\164\x5f\143\x6f\x76\145\x72");
