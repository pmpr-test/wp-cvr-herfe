<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9fdf1fbfc             |
    |_______________________________________|
*/
 pmpr_do_action("\x69\x6e\x69\164\x5f\143\157\x76\145\x72");
