<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d8c7dc1c6             |
    |_______________________________________|
*/
 pmpr_do_action("\151\x6e\151\164\x5f\x63\x6f\x76\x65\x72");
