<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc71d551ce8             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
