<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6800f8631a131             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
